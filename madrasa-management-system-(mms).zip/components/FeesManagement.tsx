
import React, { useState } from 'react';
import { Wallet, TrendingUp, CheckCircle2, User, Info } from 'lucide-react';
import { Student, Transaction, TransactionCategory } from '../types';

interface FeesProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  categories: TransactionCategory[];
}

const FeesManagement: React.FC<FeesProps> = ({ students, setStudents, transactions, setTransactions, categories }) => {
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [success, setSuccess] = useState(false);

  const selectedStudent = students.find(s => s.id === selectedStudentId);

  const handlePayment = () => {
    if (!selectedStudent || !amount || parseFloat(amount) <= 0) {
      return alert('অনুগ্রহ করে শিক্ষার্থী ও সঠিক টাকার পরিমাণ দিন');
    }
    const payment = parseFloat(amount);
    
    // 1. Update Student Dues
    setStudents(prev => prev.map(s => {
      if (s.id === selectedStudentId) {
        return { ...s, dues: Math.max(0, s.dues - payment) };
      }
      return s;
    }));

    // 2. Automatically Record as Income Transaction
    const feeCategory = categories.find(c => c.type === 'income') || { id: 'default', name: 'বেতন/ফি' };
    const newTx: Transaction = {
      id: Date.now().toString(),
      type: 'income',
      categoryId: feeCategory.id,
      amount: payment,
      date: new Date().toISOString().split('T')[0],
      note: note || `${selectedStudent.name} (রোল: ${selectedStudent.roll}) - এর ফি জমা`
    };
    setTransactions([newTx, ...transactions]);

    setSuccess(true);
    setAmount('');
    setNote('');
    setTimeout(() => setSuccess(false), 3000);
  };

  const totalDues = students.reduce((acc, curr) => acc + curr.dues, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-[40px] border shadow-sm">
            <h3 className="text-xl font-black mb-8 flex items-center gap-3 text-slate-800">
              <div className="p-2 bg-emerald-100 text-emerald-600 rounded-xl"><Wallet size={20} /></div>
              বেতন ও ফি কালেকশন
            </h3>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">শিক্ষার্থী নির্বাচন করুন</label>
                <div className="relative">
                  <select 
                    value={selectedStudentId}
                    onChange={(e) => setSelectedStudentId(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold appearance-none transition-all"
                  >
                    <option value="">ছাত্র সিলেক্ট করুন...</option>
                    {students.map(s => (
                      <option key={s.id} value={s.id}>{s.name} (রোল: {s.roll}) - বকেয়া: ৳{s.dues}</option>
                    ))}
                  </select>
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                </div>
              </div>

              {selectedStudent && (
                <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100 flex justify-between items-center animate-in slide-in-from-top-2 duration-300">
                  <div>
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.2em] mb-1">বর্তমান বকেয়া (Dues)</p>
                    <p className="text-4xl font-black text-emerald-900 leading-none">৳ {selectedStudent.dues.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-emerald-800">{selectedStudent.name}</p>
                    <p className="text-xs text-emerald-600 font-bold uppercase tracking-widest">{selectedStudent.class} বিভাগ</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">জমার পরিমাণ (টাকা)</label>
                    <input 
                      type="number" 
                      inputMode="numeric"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-black text-2xl transition-all"
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">নোট (ঐচ্ছিক)</label>
                    <input 
                      type="text" 
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="যেমন: জানু-ফেব্রু মাসের বেতন"
                      className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold transition-all"
                    />
                 </div>
              </div>

              <button 
                onClick={handlePayment}
                className="w-full bg-emerald-600 text-white py-5 rounded-[24px] font-black text-xl hover:bg-emerald-700 shadow-xl shadow-emerald-100 transition-all active:scale-95 flex items-center justify-center gap-3"
              >
                টাকা জমা নিন <TrendingUp size={24} />
              </button>

              {success && (
                <div className="flex items-center gap-3 justify-center p-5 bg-emerald-900 text-emerald-100 rounded-2xl font-black animate-in zoom-in duration-300 shadow-xl">
                  <CheckCircle2 size={24} className="text-emerald-400" /> ফি সফলভাবে গ্রহণ করা হয়েছে এবং আয় হিসাবে জমা হয়েছে!
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-emerald-800 text-white p-8 rounded-[40px] shadow-2xl relative overflow-hidden">
            <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
            <div className="flex justify-between items-center mb-10">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md"><Wallet size={28} /></div>
              <span className="bg-emerald-400 text-emerald-900 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest">Live Updates</span>
            </div>
            <p className="text-emerald-200 text-xs font-black uppercase tracking-widest">মাদরাসার মোট বকেয়া</p>
            <h2 className="text-5xl font-black mt-2 leading-none">৳ {totalDues.toLocaleString()}</h2>
            <div className="mt-12 pt-8 border-t border-white/10 flex flex-col gap-5">
               <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-200 uppercase tracking-widest">মোট শিক্ষার্থী</span>
                  <span className="text-xl font-black">{students.length} জন</span>
               </div>
               <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-200 uppercase tracking-widest">গড় বকেয়া</span>
                  <span className="text-xl font-black">৳ {students.length > 0 ? Math.round(totalDues/students.length).toLocaleString() : 0}</span>
               </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-100 flex gap-4">
             <div className="w-12 h-12 rounded-2xl bg-slate-50 text-slate-400 flex items-center justify-center shrink-0">
                <Info size={24} />
             </div>
             <div>
                <p className="text-xs font-black text-slate-800 uppercase tracking-widest mb-1">প্রয়োজনীয় তথ্য</p>
                <p className="text-xs text-slate-500 leading-relaxed font-bold">এখানে ফি জমা নেওয়ার সাথে সাথে স্বয়ংক্রিয়ভাবে লেনদেন রিপোর্টে আয় হিসাবে জমা হয়ে যাবে। আপনাকে আলাদাভাবে আয় এন্ট্রি করতে হবে না।</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeesManagement;
