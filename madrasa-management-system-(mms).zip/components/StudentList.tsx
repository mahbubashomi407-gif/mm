
import React, { useState } from 'react';
import { 
  Plus, 
  Trash2,
  Edit,
  X,
  Search,
  AlertTriangle,
  MapPin,
  ChevronDown
} from 'lucide-react';
import { Student, Jamat } from '../types';

interface StudentListProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  classes: Jamat[];
}

const StudentList: React.FC<StudentListProps> = ({ students, setStudents, classes }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Using string values for numeric fields in form to allow easy typing on mobile
  const [formData, setFormData] = useState({
    name: '', 
    class: '', 
    roll: '', 
    guardianName: '', 
    phone: '', 
    address: '', 
    status: 'active' as 'active' | 'inactive', 
    dues: ''
  });

  const handleOpenModal = (student?: Student) => {
    if (student) {
      setEditingStudent(student);
      setFormData({
        name: student.name,
        class: student.class,
        roll: student.roll.toString(),
        guardianName: student.guardianName,
        phone: student.phone,
        address: student.address,
        status: student.status,
        dues: student.dues.toString()
      });
    } else {
      setEditingStudent(null);
      setFormData({ 
        name: '', 
        class: classes.length > 0 ? classes[0].name : '', 
        roll: '', 
        guardianName: '', 
        phone: '', 
        address: '', 
        status: 'active', 
        dues: '0' 
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.name) return alert('অনুগ্রহ করে পূর্ণ নাম লিখুন');
    if (!formData.class) return alert('অনুগ্রহ করে জামাত নির্বাচন করুন');
    
    const studentData: Student = {
      id: editingStudent ? editingStudent.id : Date.now().toString(),
      name: formData.name,
      class: formData.class,
      roll: parseInt(formData.roll) || 0,
      guardianName: formData.guardianName,
      phone: formData.phone,
      address: formData.address,
      status: formData.status,
      dues: parseFloat(formData.dues) || 0
    };

    if (editingStudent) {
      setStudents(prev => prev.map(s => s.id === editingStudent.id ? studentData : s));
    } else {
      setStudents(prev => [...prev, studentData]);
    }
    setIsModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteId) {
      setStudents(prev => prev.filter(s => s.id !== deleteId));
      setDeleteId(null);
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.roll.toString().includes(searchTerm) ||
    (s.address && s.address.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6 relative">
      {/* Success Toast */}
      {showToast && (
        <div className="fixed top-10 right-10 bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl z-[100] flex items-center gap-3 animate-in slide-in-from-right duration-300 font-bold">
          <Trash2 size={20} /> সফলভাবে মুছে ফেলা হয়েছে
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-sm rounded-[32px] p-8 shadow-2xl animate-in zoom-in duration-200 text-center">
            <div className="w-20 h-20 bg-rose-100 text-rose-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <AlertTriangle size={40} />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-2">আপনি কি নিশ্চিত?</h3>
            <p className="text-gray-500 font-medium mb-8">এই শিক্ষার্থীর সকল তথ্য চিরতরে মুছে যাবে। এটি আর ফিরিয়ে আনা সম্ভব নয়।</p>
            <div className="flex flex-col gap-3">
              <button onClick={confirmDelete} className="w-full bg-rose-600 text-white py-4 rounded-2xl font-black text-lg hover:bg-rose-700 transition-all active:scale-95">হ্যাঁ, মুছে ফেলুন</button>
              <button onClick={() => setDeleteId(null)} className="w-full bg-gray-100 text-gray-600 py-4 rounded-2xl font-black text-lg hover:bg-gray-200 transition-all active:scale-95">না, ফিরে যান</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-gray-900 mb-1">শিক্ষার্থী তালিকা</h2>
          <p className="text-gray-500 font-medium">মাদরাসার সকল ছাত্রের তথ্য এখান থেকে নিয়ন্ত্রণ করুন।</p>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-emerald-600 text-white px-5 py-3 rounded-xl text-sm font-bold hover:bg-emerald-700 shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95">
          <Plus size={20} /> নতুন ভর্তি
        </button>
      </div>

      <div className="bg-white rounded-[32px] shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b flex items-center gap-4 bg-gray-50/50">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="নাম, রোল বা ঠিকানা দিয়ে খুঁজুন..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-white border-2 border-transparent focus:border-emerald-500 rounded-2xl outline-none text-sm font-bold transition-all" />
          </div>
        </div>
        
        <div className="overflow-x-auto table-container">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead className="bg-gray-50/50 border-b text-gray-400 uppercase text-xs font-black tracking-widest">
              <tr>
                <th className="px-6 py-5">রোল</th>
                <th className="px-6 py-5">নাম ও ঠিকানা</th>
                <th className="px-6 py-5">যোগাযোগ</th>
                <th className="px-6 py-5">জামাত</th>
                <th className="px-6 py-5">বকেয়া</th>
                <th className="px-6 py-5 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredStudents.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-12 text-center text-gray-400 font-medium italic">কোনো শিক্ষার্থী পাওয়া যায়নি</td></tr>
              ) : (
                filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-emerald-50/30 transition-colors group">
                    <td className="px-6 py-5 font-black text-emerald-700 text-lg">#{student.roll}</td>
                    <td className="px-6 py-5">
                      <div className="max-w-xs">
                        <p className="font-black text-gray-800">{student.name}</p>
                        <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-0.5 font-bold"><MapPin size={10} className="shrink-0 text-emerald-500" /> {student.address || 'ঠিকানা নেই'}</p>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                       <p className="text-xs font-black text-gray-700">{student.phone}</p>
                       <p className="text-[10px] text-gray-400 font-black uppercase tracking-tighter mt-1">অভিভাবক: {student.guardianName}</p>
                    </td>
                    <td className="px-6 py-5"><span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-lg text-xs font-black">{student.class}</span></td>
                    <td className="px-6 py-5 font-black text-sm text-rose-600">৳ {student.dues.toLocaleString()}</td>
                    <td className="px-6 py-5 text-right">
                      <div className="flex justify-end gap-2 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                         <button onClick={() => handleOpenModal(student)} className="p-3 text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all"><Edit size={18} /></button>
                         <button onClick={() => setDeleteId(student.id)} className="p-3 text-rose-600 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={18} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in duration-200 my-8">
            <div className="p-6 border-b flex justify-between items-center bg-emerald-900 text-white sticky top-0 z-10">
              <h3 className="text-xl font-black">{editingStudent ? 'তথ্য আপডেট করুন' : 'নতুন শিক্ষার্থী ভর্তি'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="bg-white/10 p-2 rounded-xl hover:bg-white/20 transition-colors"><X /></button>
            </div>
            <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="md:col-span-2">
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">শিক্ষার্থীর পুরো নাম</label>
                  <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="নাম লিখুন..." className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 transition-all font-bold" />
                </div>
                
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">জামাত</label>
                  <div className="relative">
                    <select value={formData.class} onChange={e => setFormData({...formData, class: e.target.value})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold appearance-none transition-all">
                      <option value="">নির্বাচন করুন</option>
                      {classes.map(cls => <option key={cls.id} value={cls.name}>{cls.name}</option>)}
                    </select>
                    <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">রোল নম্বর</label>
                  <input type="text" inputMode="numeric" value={formData.roll} onChange={e => setFormData({...formData, roll: e.target.value.replace(/[^0-9]/g, '')})} placeholder="00" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-black" />
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">অভিভাবকের নাম</label>
                  <input type="text" value={formData.guardianName} onChange={e => setFormData({...formData, guardianName: e.target.value})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">মোবাইল নম্বর</label>
                  <input type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="017xxxxxxxx" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">স্থায়ী ঠিকানা</label>
                  <textarea value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} rows={2} placeholder="গ্রাম, ডাকঘর, জেলা..." className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 transition-all font-bold resize-none"></textarea>
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">স্ট্যাটাস</label>
                  <div className="relative">
                    <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as 'active'|'inactive'})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold appearance-none transition-all">
                      <option value="active">সক্রিয়</option>
                      <option value="inactive">নিষ্ক্রিয়</option>
                    </select>
                    <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">বকেয়া পরিমাণ</label>
                  <input type="text" inputMode="decimal" value={formData.dues} onChange={e => setFormData({...formData, dues: e.target.value.replace(/[^0-9.]/g, '')})} placeholder="0.00" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-black text-emerald-700" />
                </div>
              </div>
            </div>
            <div className="p-6 border-t bg-gray-50">
              <button onClick={handleSave} className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xl hover:bg-emerald-700 shadow-xl shadow-emerald-100 transition-all active:scale-95">
                {editingStudent ? 'তথ্য সেভ করুন' : 'ভর্তি সম্পন্ন করুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentList;
