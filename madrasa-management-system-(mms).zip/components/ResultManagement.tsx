
import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, ClipboardList, Printer, Trash2, ChevronRight,
  BookOpen, AlertCircle, Info, Download, Building2
} from 'lucide-react';
import { Student, Jamat, Subject, Exam, ResultRecord, MadrasaProfile } from '../types';

interface ResultProps {
  students: Student[];
  classes: Jamat[];
  subjects: Subject[];
  exams: Exam[];
  setExams: React.Dispatch<React.SetStateAction<Exam[]>>;
  results: ResultRecord[];
  setResults: React.Dispatch<React.SetStateAction<ResultRecord[]>>;
  profile: MadrasaProfile;
}

const ResultManagement: React.FC<ResultProps> = ({ 
  students, classes, subjects, exams, setExams, results, setResults, profile 
}) => {
  const [activeTab, setActiveTab] = useState<'entry' | 'reports' | 'exams' | 'marksheet'>('entry');
  const [selectedExam, setSelectedExam] = useState<string>('');
  const [selectedJamat, setSelectedJamat] = useState<string>('');
  const [newExamName, setNewExamName] = useState('');
  const [searchRoll, setSearchRoll] = useState('');
  const [marksheetStudent, setMarksheetStudent] = useState<Student | null>(null);

  useEffect(() => {
    if (exams.length > 0 && !selectedExam) setSelectedExam(exams[0].id);
    if (classes.length > 0 && !selectedJamat) setSelectedJamat(classes[0].name);
  }, [exams, classes]);

  const getGrade = (marks: number) => {
    const val = Number(marks) || 0;
    if (val >= 80) return { name: 'মুমতাজ (A+)', color: 'text-emerald-700' };
    if (val >= 65) return { name: 'জায়্যিদ জিদ্দান (A)', color: 'text-blue-700' };
    if (val >= 50) return { name: 'জায়্যিদ (B)', color: 'text-indigo-700' };
    if (val >= 33) return { name: 'মাকবুল (C)', color: 'text-orange-700' };
    return { name: 'রাসিব (F)', color: 'text-rose-700' };
  };

  const handleSaveMarks = (studentId: string, subjectId: string, value: string) => {
    if (!selectedExam) return alert('আগে একটি পরীক্ষা নির্বাচন করুন');
    
    let marks = value === '' ? 0 : parseInt(value);
    if (isNaN(marks)) marks = 0;
    if (marks > 100) marks = 100;
    if (marks < 0) marks = 0;

    setResults(prev => {
      const existing = prev.find(r => r.studentId === studentId && r.examId === selectedExam);
      if (existing) {
        const newMarks = [...existing.marks];
        const idx = newMarks.findIndex(m => m.subjectId === subjectId);
        if (idx > -1) newMarks[idx].obtainedMarks = marks;
        else newMarks.push({ subjectId, obtainedMarks: marks });
        return prev.map(r => r.id === existing.id ? { ...r, marks: newMarks } : r);
      }
      return [...prev, { id: Date.now().toString(), studentId, examId: selectedExam, marks: [{ subjectId, obtainedMarks: marks }] }];
    });
  };

  const calculateTotal = (studentId: string) => {
    const res = results.find(r => r.studentId === studentId && r.examId === selectedExam);
    return res?.marks.reduce((acc, m) => acc + (Number(m.obtainedMarks) || 0), 0) || 0;
  };

  const handlePrint = () => {
    window.print();
  };

  const currentJamatId = classes.find(c => c.name === selectedJamat)?.id;
  const currentSubjects = subjects.filter(s => s.jamatId === currentJamatId);
  const currentStudents = students.filter(s => s.class === selectedJamat);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 print-hidden">
        <h2 className="text-2xl font-black text-slate-900">পরীক্ষা ও ফলাফল</h2>
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border overflow-x-auto w-full md:w-auto">
          {[
            { id: 'entry', label: 'নম্বর এন্ট্রি' },
            { id: 'reports', label: 'রেজাল্ট শিট' },
            { id: 'marksheet', label: 'মার্কশীট' },
            { id: 'exams', label: 'পরীক্ষা সেটআপ' }
          ].map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id as any)} className={`px-4 py-2 rounded-xl text-sm font-bold whitespace-nowrap flex-1 md:flex-none transition-all ${activeTab === t.id ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'exams' && (
        <div className="bg-white p-8 rounded-[32px] border shadow-sm print-hidden animate-in fade-in duration-300">
          <h3 className="text-xl font-black mb-6 flex items-center gap-2"><ClipboardList className="text-emerald-600" /> পরীক্ষার তালিকা ও ব্যবস্থাপনা</h3>
          <div className="flex gap-2 mb-8">
            <input type="text" value={newExamName} onChange={e => setNewExamName(e.target.value)} placeholder="পরীক্ষার নাম (যেমন: সাময়িক পরীক্ষা ২০২৪)" className="flex-1 p-4 bg-slate-50 rounded-2xl outline-none border-2 border-transparent focus:border-emerald-500 font-bold" />
            <button onClick={() => {if(newExamName) setExams([...exams, {id: Date.now().toString(), name: newExamName}]); setNewExamName('')}} className="bg-emerald-600 text-white px-8 rounded-2xl font-black shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all">যোগ করুন</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {exams.map(ex => (
              <div key={ex.id} className="p-5 bg-slate-50 rounded-2xl border flex justify-between items-center group">
                <span className="font-black text-slate-700">{ex.name}</span>
                <button onClick={() => setExams(exams.filter(e => e.id !== ex.id))} className="text-rose-300 hover:text-rose-600 p-2 transition-colors"><Trash2 size={18}/></button>
              </div>
            ))}
            {exams.length === 0 && <p className="col-span-full text-center text-slate-400 font-bold py-10">কোনো পরীক্ষা সেট করা নেই</p>}
          </div>
        </div>
      )}

      {activeTab === 'entry' && (
        <div className="space-y-4 print-hidden animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">পরীক্ষা নির্বাচন</label>
                <select value={selectedExam} onChange={e => setSelectedExam(e.target.value)} className="w-full p-4 rounded-2xl bg-white border-2 border-transparent focus:border-emerald-500 shadow-sm font-black outline-none">{exams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
             </div>
             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">জামাত নির্বাচন</label>
                <select value={selectedJamat} onChange={e => setSelectedJamat(e.target.value)} className="w-full p-4 rounded-2xl bg-white border-2 border-transparent focus:border-emerald-500 shadow-sm font-black outline-none">{classes.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}</select>
             </div>
          </div>
          
          <div className="bg-white rounded-[32px] border shadow-sm overflow-hidden overflow-x-auto table-container">
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b">
                <tr>
                  <th className="p-5 text-xs font-black text-slate-400 uppercase tracking-widest">রোল ও নাম</th>
                  {currentSubjects.map(s => <th key={s.id} className="p-5 text-center text-xs font-black text-slate-400 uppercase tracking-widest">{s.name}</th>)}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentStudents.map(s => (
                  <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-5">
                       <p className="font-black text-slate-800">{s.name}</p>
                       <p className="text-xs font-bold text-emerald-600">রোল: #{s.roll}</p>
                    </td>
                    {currentSubjects.map(sub => (
                    <td key={sub.id} className="p-2 text-center">
                      <input 
                        type="text" 
                        inputMode="numeric" 
                        value={results.find(r => r.studentId === s.id && r.examId === selectedExam)?.marks.find(m => m.subjectId === sub.id)?.obtainedMarks ?? ''} 
                        onChange={e => handleSaveMarks(s.id, sub.id, e.target.value.replace(/[^0-9]/g, ''))} 
                        className="w-14 h-12 bg-slate-100 rounded-xl text-center font-black text-lg border-2 border-transparent focus:border-emerald-500 focus:bg-white outline-none transition-all" 
                      />
                    </td>
                  ))}</tr>
                ))}
                {currentStudents.length === 0 && <tr><td colSpan={currentSubjects.length + 1} className="p-10 text-center text-slate-400 font-bold italic">এই জামাতে কোনো শিক্ষার্থী নেই</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="space-y-6 animate-in fade-in duration-300">
           <div className="flex gap-2 print-hidden">
              <button onClick={handlePrint} className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 shadow-xl active:scale-95 transition-all">
                 <Printer size={20} /> রেজাল্ট শিট প্রিন্ট / PDF
              </button>
           </div>
           
           <div className="print-area-container p-4 bg-white min-h-screen relative overflow-hidden">
              {profile.logo && (
                <div className="watermark-overlay" style={{ display: 'flex', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%) rotate(-45deg)', opacity: 0.08, zIndex: 0, pointerEvents: 'none', width: '80%', justifyContent: 'center', alignItems: 'center' }}>
                  <img src={profile.logo} alt="watermark" className="w-[500px] h-auto grayscale" />
                </div>
              )}

              <div className="relative z-10">
                <div className="p-10 text-center border-b-4 border-emerald-900 mb-8 flex flex-col items-center">
                   <h1 className="text-5xl font-black text-emerald-900 mb-2">{profile.name}</h1>
                   <p className="text-slate-600 font-bold text-lg mb-4">{profile.address}</p>
                   <div className="mt-6 bg-emerald-900 text-white px-10 py-3 rounded-full font-black uppercase tracking-[0.2em] text-xs shadow-lg">
                      রেজাল্ট শিট: {exams.find(e => e.id === selectedExam)?.name || '---'}
                   </div>
                   <div className="mt-3 text-emerald-700 font-black text-xl">জামাত: {selectedJamat}</div>
                </div>

                <table className="w-full border-collapse border-2 border-slate-300">
                   <thead className="bg-emerald-900 text-white font-bold">
                      <tr>
                         <th className="border-2 border-slate-300 p-5 text-center">রোল</th>
                         <th className="border-2 border-slate-300 p-5 text-left">শিক্ষার্থীর নাম</th>
                         <th className="border-2 border-slate-300 p-5 text-center">মোট প্রাপ্ত নম্বর</th>
                         <th className="border-2 border-slate-300 p-5 text-center">ফলাফল / গ্রেড</th>
                      </tr>
                   </thead>
                   <tbody>
                      {currentStudents.map(s => {
                         const total = calculateTotal(s.id);
                         const avg = currentSubjects.length > 0 ? (total / currentSubjects.length) : 0;
                         const grade = getGrade(avg);
                         return (
                            <tr key={s.id} className="font-bold border-b text-lg">
                               <td className="border-2 border-slate-300 p-5 text-center">#{s.roll}</td>
                               <td className="border-2 border-slate-300 p-5">{s.name}</td>
                               <td className="border-2 border-slate-300 p-5 text-center text-emerald-700 text-2xl font-black">{total}</td>
                               <td className={`border-2 border-slate-300 p-5 text-center ${grade.color}`}>{grade.name}</td>
                            </tr>
                         );
                      })}
                   </tbody>
                </table>

                <div className="mt-32 flex justify-between px-10 mb-10">
                   <div className="border-t-2 border-slate-300 pt-4 w-52 text-center text-[11px] font-black uppercase tracking-widest text-slate-400">নাজেম-এ-তা'লীমাত</div>
                   <div className="border-t-2 border-emerald-900 pt-4 w-52 text-center text-[11px] font-black uppercase tracking-widest text-emerald-900 font-black">মুহতামিম / অধ্যক্ষ</div>
                </div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'marksheet' && (
        <div className="space-y-6 animate-in fade-in duration-300">
           <div className="bg-white p-8 rounded-[32px] border shadow-sm print-hidden">
              <h3 className="text-xl font-black mb-6 flex items-center gap-2 text-slate-800"><Search className="text-emerald-600" /> ব্যক্তিগত মার্কশীট খুঁজুন</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                 <input 
                    type="text" 
                    placeholder="রোল নম্বর লিখুন..." 
                    value={searchRoll} 
                    onChange={e => setSearchRoll(e.target.value.replace(/[^0-9]/g, ''))} 
                    className="flex-1 p-5 bg-slate-50 rounded-2xl outline-none border-2 border-transparent focus:border-emerald-500 font-black text-xl transition-all" 
                 />
                 <button 
                    onClick={() => {
                      const found = students.find(s => s.roll.toString() === searchRoll);
                      if (found) setMarksheetStudent(found);
                      else alert('এই রোলের কোনো শিক্ষার্থী পাওয়া যায়নি');
                    }} 
                    className="bg-emerald-600 text-white px-10 py-5 rounded-2xl font-black text-lg hover:bg-emerald-700 shadow-xl transition-all active:scale-95"
                 >খুঁজুন</button>
              </div>
           </div>

           {marksheetStudent && (
             <div className="print-area-container relative">
                {profile.logo && (
                  <div className="watermark-overlay" style={{ display: 'flex', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%) rotate(-45deg)', opacity: 0.08, zIndex: 0, pointerEvents: 'none', width: '80%', justifyContent: 'center', alignItems: 'center' }}>
                    <img src={profile.logo} alt="watermark" className="w-[500px] h-auto grayscale" />
                  </div>
                )}

                <div className="bg-white border-4 border-emerald-900 rounded-[48px] p-10 md:p-14 mb-10 overflow-hidden relative shadow-2xl print:shadow-none print:border-none z-10">
                   <div className="flex flex-col items-center mb-10 text-center">
                      <h2 className="text-5xl font-black text-emerald-900 leading-tight">{profile.name}</h2>
                      <p className="font-bold text-slate-600 mt-3 text-xl">{profile.address}</p>
                      <div className="w-40 h-1 bg-emerald-900/10 mt-8 mb-4 rounded-full"></div>
                      <p className="text-xs font-black text-slate-400 uppercase tracking-[0.5em] underline decoration-emerald-200 decoration-4 underline-offset-8">Academic Transcript</p>
                   </div>
                   
                   <div className="grid grid-cols-2 gap-8 mb-10 bg-emerald-50 p-12 rounded-[48px]">
                      <div>
                         <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest mb-2">Student Name</p>
                         <p className="text-4xl font-black text-slate-800">{marksheetStudent.name}</p>
                         <p className="font-bold text-slate-500 mt-2 text-xl italic">জামাত: {marksheetStudent.class}</p>
                      </div>
                      <div className="text-right">
                         <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest mb-2">Academic Roll</p>
                         <p className="text-6xl font-black text-emerald-900">#{marksheetStudent.roll}</p>
                         <p className="font-bold text-slate-500 mt-2 text-xl italic">পরীক্ষা: {exams.find(e => e.id === selectedExam)?.name || '---'}</p>
                      </div>
                   </div>

                   <div className="border-2 border-emerald-900 rounded-[40px] overflow-hidden mb-12 shadow-sm">
                      <div className="grid grid-cols-3 bg-emerald-900 text-white p-7 font-black text-xs uppercase tracking-[0.2em]">
                         <span>KITAB / SUBJECT</span><span className="text-center">FULL MARKS</span><span className="text-right">OBTAINED</span>
                      </div>
                      {subjects.filter(s => s.jamatId === classes.find(c => c.name === marksheetStudent.class)?.id).map((sub, idx) => {
                         const mark = results.find(r => r.studentId === marksheetStudent.id && r.examId === selectedExam)?.marks.find(m => m.subjectId === sub.id)?.obtainedMarks || 0;
                         return (
                            <div key={sub.id} className={`grid grid-cols-3 p-7 border-b-2 border-slate-50 font-bold items-center ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'}`}>
                               <span className="text-slate-800 text-xl font-black">{sub.name}</span>
                               <span className="text-center text-slate-300">১০০</span>
                               <span className="text-right text-emerald-600 text-4xl font-black">{mark}</span>
                            </div>
                         );
                      })}
                   </div>

                   <div className="flex justify-between items-center bg-emerald-900 text-white p-14 rounded-[48px] shadow-2xl relative">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16"></div>
                      <div>
                         <p className="text-xs opacity-70 font-black uppercase tracking-[0.3em] mb-3">Grand Total Marks</p>
                         <p className="text-8xl font-black">{calculateTotal(marksheetStudent.id)}</p>
                      </div>
                      <div className="text-right">
                         <p className="text-xs opacity-70 font-black uppercase tracking-[0.3em] mb-3">Overall Grade</p>
                         <p className="text-6xl font-black">{getGrade(calculateTotal(marksheetStudent.id) / Math.max(1, subjects.filter(s => s.jamatId === classes.find(c => c.name === marksheetStudent.class)?.id).length)).name}</p>
                      </div>
                   </div>

                   <div className="mt-24 flex justify-between px-10">
                      <div className="border-t-2 border-slate-300 pt-5 w-52 text-center text-[12px] font-black uppercase tracking-widest text-slate-400">পরীক্ষা নিয়ন্ত্রক</div>
                      <div className="border-t-2 border-emerald-900 pt-5 w-52 text-center text-[12px] font-black uppercase tracking-widest text-emerald-900 font-black">মুহতামিম / প্রিন্সিপাল</div>
                   </div>

                   <div className="mt-16 flex justify-center print:hidden">
                      <button onClick={handlePrint} className="bg-slate-900 text-white px-12 py-5 rounded-2xl font-black flex items-center gap-3 shadow-2xl hover:scale-105 transition-all active:scale-95">
                         <Printer size={24} /> মার্কশীট প্রিন্ট / PDF সেভ
                      </button>
                   </div>
                </div>
             </div>
           )}
        </div>
      )}
    </div>
  );
};

export default ResultManagement;
