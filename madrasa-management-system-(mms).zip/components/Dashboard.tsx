
import React from 'react';
import { 
  Users, 
  GraduationCap, 
  TrendingUp, 
  TrendingDown,
  AlertCircle,
  ArrowUpRight,
  Receipt,
  Wallet,
  Building2
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Student, Teacher, Transaction, MadrasaProfile } from '../types';

interface DashboardProps {
  students: Student[];
  teachers: Teacher[];
  transactions: Transaction[];
  profile: MadrasaProfile;
}

const StatCard = ({ title, value, icon: Icon, trend, color }: any) => (
  <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 transition-all hover:shadow-lg group">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 group-hover:scale-110 transition-transform`}>
        <Icon className={color.replace('bg-', 'text-')} size={26} />
      </div>
      {trend && (
        <div className={`flex items-center text-[10px] font-black px-2 py-1 rounded-full ${trend.includes('+') ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
          {trend} <ArrowUpRight size={10} className="ml-1" />
        </div>
      )}
    </div>
    <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{title}</h3>
    <p className="text-2xl lg:text-3xl font-black mt-2 text-slate-800 leading-none">{value}</p>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ students, teachers, transactions, profile }) => {
  const totalDues = students.reduce((acc, curr) => acc + curr.dues, 0);
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);

  // Group transactions by type for chart
  const chartData = [
    { name: 'আয় (Income)', value: totalIncome, fill: '#10b981' },
    { name: 'ব্যয় (Expense)', value: totalExpense, fill: '#f43f5e' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white rounded-3xl shadow-xl flex items-center justify-center border-2 border-emerald-50 overflow-hidden">
             {profile.logo ? <img src={profile.logo} className="w-full h-full object-cover" /> : <Building2 size={32} className="text-emerald-900" />}
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-900 mb-1 leading-tight">আসসালামু আলাইকুম!</h2>
            <p className="text-emerald-700 font-bold">{profile.name}</p>
          </div>
        </div>
        <div className="flex gap-2">
           <div className="px-4 py-2 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-black text-slate-600 uppercase tracking-widest">সিস্টেম অনলাইন</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6">
        <StatCard title="মোট শিক্ষার্থী" value={`${students.length} জন`} icon={GraduationCap} color="bg-blue-600" />
        <StatCard title="মোট শিক্ষক" value={`${teachers.length} জন`} icon={Users} color="bg-purple-600" />
        <StatCard title="মোট আয় (ক্যাশ)" value={`৳ ${totalIncome.toLocaleString()}`} icon={TrendingUp} color="bg-emerald-600" />
        <StatCard title="বকেয়া ফি" value={`৳ ${totalDues.toLocaleString()}`} icon={AlertCircle} color="bg-rose-600" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 bg-white p-6 lg:p-8 rounded-[40px] border shadow-sm">
          <div className="flex justify-between items-center mb-8">
             <h3 className="text-xl font-black text-slate-800">আয় ও ব্যয়ের তুলনা</h3>
             <div className="flex gap-4">
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-emerald-500"></div><span className="text-[10px] font-black text-slate-400 uppercase">আয়</span></div>
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-rose-500"></div><span className="text-[10px] font-black text-slate-400 uppercase">ব্যয়</span></div>
             </div>
          </div>
          <div className="h-72 lg:h-96 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip cursor={{fill: 'transparent'}} contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                <Bar dataKey="value" radius={[12, 12, 12, 12]} barSize={60}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 lg:p-8 rounded-[40px] border shadow-sm flex flex-col">
          <h3 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-2"><Receipt className="text-emerald-600" /> সাম্প্রতিক লেনদেন</h3>
          <div className="space-y-4 flex-1">
            {transactions.slice(0, 5).map((tx) => (
              <div key={tx.id} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${tx.type === 'income' ? 'border-emerald-50 bg-emerald-50/20' : 'border-rose-50 bg-rose-50/20'}`}>
                <div className={`p-2 rounded-xl ${tx.type === 'income' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                  {tx.type === 'income' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-black text-slate-800 truncate">{tx.note || 'লেনদেন'}</p>
                  <p className="text-[10px] text-slate-400 font-bold">{tx.date}</p>
                </div>
                <p className={`text-sm font-black whitespace-nowrap ${tx.type === 'income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  ৳{tx.amount}
                </p>
              </div>
            ))}
            {transactions.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-slate-300 opacity-50">
                 <Wallet size={48} className="mb-2" />
                 <p className="text-xs font-black uppercase tracking-widest">কোনো রেকর্ড নেই</p>
              </div>
            )}
          </div>
          <button className="mt-6 w-full py-4 bg-slate-50 text-slate-600 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-100 transition-colors">সকল লেনদেন দেখুন</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
