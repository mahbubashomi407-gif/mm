
import React, { useState } from 'react';
import { Camera, Building2, MapPin, Phone, Mail, Calendar, CheckCircle2 } from 'lucide-react';
import { MadrasaProfile } from '../types';

interface ProfileProps {
  profile: MadrasaProfile;
  setProfile: React.Dispatch<React.SetStateAction<MadrasaProfile>>;
}

const ProfileSettings: React.FC<ProfileProps> = ({ profile, setProfile }) => {
  const [formData, setFormData] = useState<MadrasaProfile>(profile);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    setProfile(formData);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 mb-1">মাদরাসা প্রোফাইল</h2>
          <p className="text-slate-500 font-medium">মাদরাসার দাপ্তরিক তথ্য ও ব্র্যান্ডিং সেট করুন</p>
        </div>
        {showSuccess && (
          <div className="bg-emerald-900 text-white px-6 py-3 rounded-2xl font-black flex items-center gap-3 shadow-xl animate-in slide-in-from-top duration-300">
            <CheckCircle2 size={20} className="text-emerald-400" /> তথ্য আপডেট হয়েছে!
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-[40px] border shadow-sm flex flex-col items-center text-center">
            <div className="relative group mb-6">
              <div className="w-40 h-40 bg-slate-100 rounded-[40px] border-4 border-white shadow-xl overflow-hidden flex items-center justify-center">
                {formData.logo ? (
                  <img src={formData.logo} className="w-full h-full object-cover" />
                ) : (
                  <Building2 size={64} className="text-slate-300" />
                )}
              </div>
              <label className="absolute -right-2 -bottom-2 bg-emerald-600 text-white p-3 rounded-2xl shadow-lg cursor-pointer hover:bg-emerald-700 transition-all active:scale-95 group-hover:scale-110">
                <Camera size={20} />
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
            </div>
            <h3 className="text-2xl font-black text-slate-800">{formData.name}</h3>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-2">মাদরাসা লোগো ও ব্র্যান্ডিং</p>
          </div>

          <div className="bg-emerald-900 p-8 rounded-[40px] text-white shadow-xl">
             <h4 className="font-black mb-6 text-emerald-200 uppercase tracking-widest text-xs">সিস্টেম ইনফো</h4>
             <div className="space-y-4">
                <div className="flex justify-between border-b border-white/10 pb-4">
                   <span className="text-emerald-300 text-sm font-bold">স্থাপিত</span>
                   <span className="font-black">{formData.established}</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-4">
                   <span className="text-emerald-300 text-sm font-bold">লোগো স্ট্যাটাস</span>
                   <span className={`font-black ${formData.logo ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {formData.logo ? 'আপলোডকৃত' : 'নাই'}
                   </span>
                </div>
             </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white p-8 md:p-10 rounded-[40px] border shadow-sm">
            <h3 className="text-xl font-black mb-8 border-b pb-6">বিস্তারিত তথ্য ফরম</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="md:col-span-2">
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">মাদরাসার পূর্ণ নাম (Bengali)</label>
                  <input 
                    type="text" 
                    value={formData.name} 
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full px-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-black text-xl transition-all"
                  />
               </div>
               
               <div className="md:col-span-2">
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">ঠিকানা (পূর্ণ বিবরণ)</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      value={formData.address} 
                      onChange={e => setFormData({...formData, address: e.target.value})}
                      className="w-full pl-14 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold transition-all"
                    />
                    <MapPin className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-600" size={20} />
                  </div>
               </div>

               <div>
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">মোবাইল নম্বর</label>
                  <div className="relative">
                    <input 
                      type="tel" 
                      value={formData.phone} 
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                      className="w-full pl-14 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold transition-all"
                    />
                    <Phone className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-600" size={20} />
                  </div>
               </div>

               <div>
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">ইমেইল ঠিকানা</label>
                  <div className="relative">
                    <input 
                      type="email" 
                      value={formData.email} 
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full pl-14 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold transition-all"
                    />
                    <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-600" size={20} />
                  </div>
               </div>

               <div>
                  <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">স্থাপিত বছর</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      value={formData.established} 
                      onChange={e => setFormData({...formData, established: e.target.value})}
                      className="w-full pl-14 pr-6 py-4 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 font-bold transition-all"
                    />
                    <Calendar className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-600" size={20} />
                  </div>
               </div>
            </div>

            <button 
              onClick={handleSave}
              className="mt-10 w-full bg-emerald-600 text-white py-5 rounded-[24px] font-black text-xl hover:bg-emerald-700 shadow-xl shadow-emerald-100 transition-all active:scale-95"
            >
              প্রোফাইল আপডেট করুন
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
