
import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Receipt,
  Printer,
  Search,
  Tag,
  Building2,
  X
} from 'lucide-react';
import { Transaction, TransactionCategory, MadrasaProfile } from '../types';

interface AccountsProps {
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  categories: TransactionCategory[];
  setCategories: React.Dispatch<React.SetStateAction<TransactionCategory[]>>;
  profile: MadrasaProfile;
}

const AccountsManagement: React.FC<AccountsProps> = ({ 
  transactions, setTransactions, categories, setCategories, profile 
}) => {
  const [activeTab, setActiveTab] = useState<'entry' | 'categories' | 'report'>('entry');
  const [type, setType] = useState<'income' | 'expense'>('income');
  const [categoryId, setCategoryId] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState('');
  
  const [newCatName, setNewCatName] = useState('');
  const [newCatType, setNewCatType] = useState<'income' | 'expense'>('income');

  const handleAddTransaction = () => {
    if (!categoryId || !amount) return alert('খাত এবং পরিমাণ আবশ্যক');
    const newTx: Transaction = {
      id: Date.now().toString(),
      type,
      categoryId,
      amount: parseFloat(amount),
      date,
      note
    };
    setTransactions([newTx, ...transactions]);
    setAmount('');
    setNote('');
    setCategoryId('');
  };

  const handleAddCategory = () => {
    if (!newCatName) return;
    setCategories([...categories, { id: Date.now().toString(), name: newCatName, type: newCatType }]);
    setNewCatName('');
  };

  const totalIncome = transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 print-hidden">
        <div>
          <h2 className="text-3xl font-black text-slate-900 mb-1">আয়-ব্যয় হিসাব</h2>
          <p className="text-slate-500 font-medium">লেনদেন পরিচালনা ও রিপোর্ট চেক করুন</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-200 overflow-x-auto w-full md:w-auto">
          {[
            { id: 'entry', label: 'লেনদেন এন্ট্রি' },
            { id: 'categories', label: 'খাতসমূহ' },
            { id: 'report', label: 'রিপোর্ট' }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap flex-1 ${activeTab === tab.id ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
            >{tab.label}</button>
          ))}
        </div>
      </div>

      {activeTab === 'entry' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-300 print-hidden">
          <div className="lg:col-span-1">
             <div className="bg-white p-8 rounded-[32px] border shadow-sm space-y-6">
                <h3 className="text-xl font-black flex items-center gap-2"><Plus className="text-emerald-600" /> নতুন এন্ট্রি</h3>
                
                <div className="flex p-1 bg-slate-100 rounded-xl">
                   <button onClick={() => setType('income')} className={`flex-1 py-3 rounded-lg text-sm font-black transition-all ${type === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}>আয়</button>
                   <button onClick={() => setType('expense')} className={`flex-1 py-3 rounded-lg text-sm font-black transition-all ${type === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400'}`}>ব্যয়</button>
                </div>

                <div className="space-y-4">
                   <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">খাত নির্বাচন (Category)</label>
                      <select value={categoryId} onChange={e => setCategoryId(e.target.value)} className="w-full p-4 mt-1 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-emerald-500 font-bold outline-none">
                         <option value="">নির্বাচন করুন</option>
                         {categories.filter(c => c.type === type).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                   </div>
                   <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">পরিমাণ (Amount)</label>
                      <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" className="w-full p-4 mt-1 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-emerald-500 font-black text-2xl outline-none" />
                   </div>
                   <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">তারিখ</label>
                      <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-4 mt-1 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-emerald-500 font-bold outline-none" />
                   </div>
                   <div>
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">বিবরণ/নোট</label>
                      <textarea value={note} onChange={e => setNote(e.target.value)} rows={2} className="w-full p-4 mt-1 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-emerald-500 font-bold outline-none resize-none" placeholder="লেনদেনের বিবরণ..."></textarea>
                   </div>
                   <button onClick={handleAddTransaction} className={`w-full py-5 rounded-2xl font-black text-lg text-white shadow-xl transition-all active:scale-95 ${type === 'income' ? 'bg-emerald-600 shadow-emerald-100 hover:bg-emerald-700' : 'bg-rose-600 shadow-rose-100 hover:bg-rose-700'}`}>এন্ট্রি করুন</button>
                </div>
             </div>
          </div>

          <div className="lg:col-span-2">
             <div className="bg-white rounded-[32px] border shadow-sm overflow-hidden">
                <div className="p-6 border-b bg-slate-50/50 flex justify-between items-center">
                   <h3 className="text-xl font-black">সাম্প্রতিক লেনদেন</h3>
                   <div className="flex gap-4">
                      <div className="text-right">
                         <p className="text-[10px] font-black text-slate-400 uppercase">মোট আয়</p>
                         <p className="font-black text-emerald-600">৳{totalIncome.toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                         <p className="text-[10px] font-black text-slate-400 uppercase">মোট ব্যয়</p>
                         <p className="font-black text-rose-600">৳{totalExpense.toLocaleString()}</p>
                      </div>
                   </div>
                </div>
                <div className="overflow-x-auto">
                   <table className="w-full">
                      <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                         <tr>
                            <th className="px-6 py-4 text-left">তারিখ</th>
                            <th className="px-6 py-4 text-left">খাত</th>
                            <th className="px-6 py-4 text-right">পরিমাণ</th>
                            <th className="px-6 py-4 text-center">অ্যাকশন</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                         {transactions.map(tx => (
                            <tr key={tx.id} className="hover:bg-slate-50">
                               <td className="px-6 py-4 font-bold text-slate-500 text-sm">{tx.date}</td>
                               <td className="px-6 py-4 font-black text-slate-800">{categories.find(c => c.id === tx.categoryId)?.name || '---'}</td>
                               <td className={`px-6 py-4 text-right font-black ${tx.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                                  {tx.type === 'income' ? '+' : '-'} ৳{tx.amount.toLocaleString()}
                               </td>
                               <td className="px-6 py-4 text-center">
                                  <button onClick={() => setTransactions(transactions.filter(t => t.id !== tx.id))} className="p-2 text-rose-300 hover:text-rose-600 transition-colors"><Trash2 size={16}/></button>
                               </td>
                            </tr>
                         ))}
                         {transactions.length === 0 && <tr><td colSpan={4} className="py-20 text-center text-slate-300 font-bold italic">কোনো লেনদেন পাওয়া যায়নি</td></tr>}
                      </tbody>
                   </table>
                </div>
             </div>
          </div>
        </div>
      )}

      {activeTab === 'categories' && (
        <div className="bg-white p-8 rounded-[32px] border shadow-sm animate-in fade-in duration-300 print-hidden">
           <h3 className="text-xl font-black mb-8 flex items-center gap-2"><Tag className="text-emerald-600" /> লেনদেনের খাত ব্যবস্থাপনা</h3>
           <div className="flex flex-col md:flex-row gap-4 mb-10">
              <input type="text" value={newCatName} onChange={e => setNewCatName(e.target.value)} placeholder="খাতের নাম (যেমন: দান-সদকা বা আপ্যায়ন)" className="flex-1 p-4 bg-slate-50 rounded-2xl outline-none border-2 border-transparent focus:border-emerald-500 font-bold" />
              <div className="flex p-1 bg-slate-100 rounded-xl h-14">
                 <button onClick={() => setNewCatType('income')} className={`px-6 rounded-lg text-sm font-black transition-all ${newCatType === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}>আয় খাত</button>
                 <button onClick={() => setNewCatType('expense')} className={`px-6 rounded-lg text-sm font-black transition-all ${newCatType === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400'}`}>ব্যয় খাত</button>
              </div>
              <button onClick={handleAddCategory} className="bg-emerald-600 text-white px-8 rounded-2xl font-black hover:bg-emerald-700 transition-all">যোগ করুন</button>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map(cat => (
                 <div key={cat.id} className={`p-5 rounded-2xl border flex justify-between items-center ${cat.type === 'income' ? 'bg-emerald-50/30 border-emerald-100' : 'bg-rose-50/30 border-rose-100'}`}>
                    <div>
                       <p className="font-black text-slate-800">{cat.name}</p>
                       <p className={`text-[10px] font-black uppercase tracking-widest ${cat.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>{cat.type === 'income' ? 'আয় খাত' : 'ব্যয় খাত'}</p>
                    </div>
                    <button onClick={() => setCategories(categories.filter(c => c.id !== cat.id))} className="text-slate-300 hover:text-rose-600 p-2"><Trash2 size={18}/></button>
                 </div>
              ))}
           </div>
        </div>
      )}

      {activeTab === 'report' && (
        <div className="space-y-6 animate-in fade-in duration-300">
           <div className="bg-white p-6 rounded-3xl border shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4 print-hidden">
              <button onClick={() => window.print()} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black hover:bg-black flex items-center gap-2 shadow-xl transition-all active:scale-95">
                 <Printer size={20} /> রিপোর্ট ডাউনলোড / প্রিন্ট
              </button>
           </div>

           <div className="print-area-container relative p-4 bg-white min-h-screen">
              {/* Logo Watermark */}
              {profile.logo && (
                <div className="watermark-overlay" style={{ display: 'flex', position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%) rotate(-45deg)', opacity: 0.08, zIndex: 0, pointerEvents: 'none', width: '80%', justifyContent: 'center', alignItems: 'center' }}>
                  <img src={profile.logo} alt="watermark" className="w-[500px] h-auto grayscale" />
                </div>
              )}

              <div className="relative z-10">
                <div className="p-12 text-center border-b-4 border-emerald-900 mb-10 flex flex-col items-center">
                   <h1 className="text-5xl font-black text-emerald-900 mb-2">{profile.name}</h1>
                   <p className="text-slate-700 font-bold text-lg mb-2">{profile.address}</p>
                   <div className="w-48 h-1 bg-emerald-900 mt-4 mb-6 rounded-full"></div>
                   <h2 className="text-2xl font-black text-emerald-700 uppercase tracking-[0.2em] border-y-2 border-emerald-50 py-3 px-12 inline-block">আয়-ব্যয় বিবরণী রিপোর্ট</h2>
                   <p className="text-[11px] text-slate-400 font-black uppercase tracking-[0.3em] mt-4 italic">জেনারেশনের তারিখ: {new Date().toLocaleDateString('bn-BD')}</p>
                </div>

                <div className="grid grid-cols-2 gap-10 mb-10 px-4">
                   <div className="p-8 border-2 border-emerald-900 rounded-[32px] bg-emerald-50/30 text-center">
                      <p className="text-xs font-black text-emerald-700 uppercase tracking-widest mb-2">মোট আয় (Total Income)</p>
                      <p className="text-5xl font-black text-emerald-900">৳{totalIncome.toLocaleString()}</p>
                   </div>
                   <div className="p-8 border-2 border-rose-900 rounded-[32px] bg-rose-50/30 text-center">
                      <p className="text-xs font-black text-rose-700 uppercase tracking-widest mb-2">মোট ব্যয় (Total Expense)</p>
                      <p className="text-5xl font-black text-rose-900">৳{totalExpense.toLocaleString()}</p>
                   </div>
                </div>

                <div className="px-4 mb-20">
                   <table className="w-full border-collapse border-2 border-slate-300">
                      <thead className="bg-slate-100 font-black text-sm">
                         <tr>
                            <th className="border-2 border-slate-300 p-5 text-left">তারিখ</th>
                            <th className="border-2 border-slate-300 p-5 text-left">খাত (Category)</th>
                            <th className="border-2 border-slate-300 p-5 text-left">বিবরণ (Note)</th>
                            <th className="border-2 border-slate-300 p-5 text-right">আয় (+)</th>
                            <th className="border-2 border-slate-300 p-5 text-right">ব্যয় (-)</th>
                         </tr>
                      </thead>
                      <tbody className="font-bold text-lg">
                         {transactions.map(tx => {
                            const cat = categories.find(c => c.id === tx.categoryId);
                            return (
                               <tr key={tx.id}>
                                  <td className="border-2 border-slate-300 p-5 text-sm">{tx.date}</td>
                                  <td className="border-2 border-slate-300 p-5">{cat?.name}</td>
                                  <td className="border-2 border-slate-300 p-5 text-slate-500 font-medium text-sm">{tx.note || '---'}</td>
                                  <td className="border-2 border-slate-300 p-5 text-right text-emerald-600">{tx.type === 'income' ? `৳${tx.amount.toLocaleString()}` : ''}</td>
                                  <td className="border-2 border-slate-300 p-5 text-right text-rose-600">{tx.type === 'expense' ? `৳${tx.amount.toLocaleString()}` : ''}</td>
                               </tr>
                            );
                         })}
                      </tbody>
                      <tfoot className="bg-emerald-900 text-white font-black">
                         <tr>
                            <td colSpan={3} className="p-6 text-right uppercase tracking-[0.2em] text-lg">বর্তমান স্থিতি (Net Balance)</td>
                            <td colSpan={2} className="p-6 text-center text-4xl">৳{(totalIncome - totalExpense).toLocaleString()}</td>
                         </tr>
                      </tfoot>
                   </table>
                </div>

                <div className="flex justify-between px-10 mb-10 mt-24">
                   <div className="text-center border-t-2 border-slate-300 pt-4 w-52 font-black text-[10px] text-slate-400 uppercase tracking-widest">হিসাবরক্ষক স্বাক্ষর</div>
                   <div className="text-center border-t-2 border-emerald-900 pt-4 w-52 font-black text-[10px] text-emerald-900 uppercase tracking-widest font-black">মুহতামিম / অধ্যক্ষ</div>
                </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default AccountsManagement;
