
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, MessageSquare } from 'lucide-react';
import { askMMSAssistant } from '../services/gemini';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'আসসালামু আলাইকুম! আমি আপনার মাদরাসা ম্যানেজমেন্ট স্মার্ট অ্যাসিস্ট্যান্ট। আমি আপনাকে কীভাবে সাহায্য করতে পারি?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    setIsLoading(true);

    const aiResponse = await askMMSAssistant(userMsg);
    setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
    setIsLoading(false);
  };

  return (
    <div className="max-w-5xl mx-auto flex flex-col h-[calc(100vh-140px)] lg:h-[calc(100vh-180px)] animate-in fade-in zoom-in duration-300">
      <div className="bg-white border-t border-x rounded-t-[32px] p-5 lg:p-6 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-200 animate-bounce-slow">
            <Bot size={28} />
          </div>
          <div>
            <h2 className="font-black text-gray-800 text-lg">স্মার্ট অ্যাসিস্ট্যান্ট</h2>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Active Now</span>
            </div>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-bold">
          <Sparkles size={14} /> AI Powered
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 lg:p-8 space-y-6 bg-white border-x custom-scrollbar"
      >
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`flex gap-3 max-w-[90%] lg:max-w-[75%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm ${
                msg.role === 'user' ? 'bg-emerald-900 text-white' : 'bg-emerald-50 text-emerald-600'
              }`}>
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              <div className={`p-4 lg:p-5 rounded-3xl shadow-sm text-sm lg:text-base leading-relaxed whitespace-pre-wrap ${
                msg.role === 'user' 
                ? 'bg-emerald-900 text-white rounded-tr-none' 
                : 'bg-gray-50 text-gray-800 border border-gray-100 rounded-tl-none font-medium'
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-50 p-4 rounded-2xl border flex gap-1.5">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce delay-100"></div>
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce delay-200"></div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white p-4 lg:p-6 border rounded-b-[32px] shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] z-10">
        <div className="relative flex items-center gap-3">
          <div className="flex-1 relative">
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="যেকোনো প্রশ্ন বা সাহায্যের জন্য এখানে লিখুন..."
              className="w-full bg-gray-100 border-2 border-transparent rounded-2xl px-5 py-4 lg:py-5 pr-14 outline-none focus:bg-white focus:border-emerald-500 focus:ring-4 focus:ring-emerald-50 transition-all text-gray-800 font-medium"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none">
              <MessageSquare size={20} />
            </div>
          </div>
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="w-14 h-14 lg:w-16 lg:h-16 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center shadow-xl shadow-emerald-100 active:scale-90 flex-shrink-0"
          >
            <Send size={24} />
          </button>
        </div>
        <p className="text-[10px] text-center text-gray-400 mt-4 flex items-center justify-center gap-1 font-bold uppercase tracking-widest">
           Gemini AI দ্বারা পরিচালিত • আপনার তথ্য নিরাপদ
        </p>
      </div>
    </div>
  );
};

export default AIAssistant;
