
import React, { useState } from 'react';
import { Mail, Phone, Calendar, UserPlus, Trash2, Edit, X, AlertCircle, ChevronDown, BookOpen } from 'lucide-react';
import { Teacher, Subject } from '../types';

interface TeacherListProps {
  teachers: Teacher[];
  setTeachers: React.Dispatch<React.SetStateAction<Teacher[]>>;
  subjects: Subject[];
}

const TeacherList: React.FC<TeacherListProps> = ({ teachers, setTeachers, subjects }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Teacher>>({
    name: '', designation: '', subject: '', phone: '', joiningDate: ''
  });

  const handleOpenModal = (teacher?: Teacher) => {
    if (teacher) {
      setEditingTeacher(teacher);
      setFormData(teacher);
    } else {
      setEditingTeacher(null);
      setFormData({ name: '', designation: '', subject: '', phone: '', joiningDate: new Date().toISOString().split('T')[0] });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.name) return alert('নাম আবশ্যক');
    if (editingTeacher) {
      setTeachers(prev => prev.map(t => String(t.id) === String(editingTeacher.id) ? { ...t, ...formData } as Teacher : t));
    } else {
      const newTeacher: Teacher = { ...formData, id: Date.now().toString() } as Teacher;
      setTeachers(prev => [...prev, newTeacher]);
    }
    setIsModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteId) {
      setTeachers(prev => prev.filter(t => String(t.id) !== String(deleteId)));
      setDeleteId(null);
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2000);
    }
  };

  return (
    <div className="space-y-6 relative">
      {/* Toast */}
      {showToast && (
        <div className="fixed top-10 right-10 bg-emerald-600 text-white px-6 py-4 rounded-2xl shadow-2xl z-[100] flex items-center gap-3 animate-in slide-in-from-right duration-300 font-bold">
          <Trash2 size={20} /> শিক্ষকের তথ্য মুছে ফেলা হয়েছে
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-sm rounded-[32px] p-8 shadow-2xl animate-in zoom-in duration-200 text-center">
            <div className="w-20 h-20 bg-rose-100 text-rose-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <AlertCircle size={40} />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-2">শিক্ষক মুছুন?</h3>
            <p className="text-gray-500 font-medium mb-8">আপনি কি নিশ্চিত যে এই শিক্ষকের সকল রেকর্ড ডিলিট করতে চান?</p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={confirmDelete}
                className="w-full bg-rose-600 text-white py-4 rounded-2xl font-black text-lg hover:bg-rose-700 transition-all active:scale-95"
              >
                হ্যাঁ, ডিলিট করুন
              </button>
              <button 
                onClick={() => setDeleteId(null)}
                className="w-full bg-gray-100 text-gray-600 py-4 rounded-2xl font-black text-lg hover:bg-gray-200 transition-all active:scale-95"
              >
                বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-gray-900 mb-1">শিক্ষক মন্ডলী</h2>
          <p className="text-gray-500 font-medium">শিক্ষকদের তথ্য নিয়ন্ত্রণ করুন।</p>
        </div>
        <button onClick={() => handleOpenModal()} className="bg-emerald-600 text-white px-5 py-3 rounded-xl flex items-center gap-2 hover:bg-emerald-700 shadow-xl transition-all active:scale-95">
          <UserPlus size={18} /> নতুন শিক্ষক
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teachers.length === 0 ? (
          <div className="col-span-full py-20 text-center text-gray-400 font-bold bg-white rounded-3xl border-2 border-dashed border-gray-100">
            কোনো শিক্ষকের তথ্য নেই
          </div>
        ) : (
          teachers.map((teacher) => (
            <div key={teacher.id} className="bg-white rounded-[40px] shadow-sm border border-gray-100 p-8 hover:border-emerald-500 transition-all relative group overflow-hidden">
              <div className="absolute top-0 right-0 p-8">
                 <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                    <BookOpen size={20} />
                 </div>
              </div>

              <div className="flex items-center gap-5 mb-8">
                <div className="w-16 h-16 rounded-2xl bg-emerald-900 text-white flex items-center justify-center text-2xl font-black shadow-lg">
                  {teacher.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-xl font-black text-gray-800 leading-tight">{teacher.name}</h3>
                  <p className="text-emerald-600 text-[10px] font-black uppercase tracking-[0.2em] mt-1">{teacher.designation}</p>
                </div>
              </div>
              
              <div className="space-y-4 pt-6 border-t border-gray-50">
                <div className="flex items-center gap-3 text-sm text-gray-600 font-bold">
                  <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-emerald-500">
                    <BookOpen size={16} />
                  </div>
                  <span>{teacher.subject}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600 font-bold">
                   <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-emerald-500">
                    <Phone size={16} />
                  </div>
                  <span>{teacher.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600 font-bold">
                   <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-emerald-500">
                    <Calendar size={16} />
                  </div>
                  <span>যোগদান: {teacher.joiningDate}</span>
                </div>
              </div>

              <div className="mt-8 flex gap-3">
                <button onClick={() => handleOpenModal(teacher)} className="flex-1 bg-emerald-50 text-emerald-700 py-4 rounded-2xl text-xs font-black hover:bg-emerald-100 transition-colors">এডিট</button>
                <button onClick={() => setDeleteId(teacher.id)} className="flex-1 bg-rose-50 text-rose-600 py-4 rounded-2xl text-xs font-black hover:bg-rose-100 transition-colors">মুছুন</button>
              </div>
            </div>
          ))
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-6 border-b flex justify-between items-center bg-emerald-900 text-white">
              <h3 className="text-xl font-black">{editingTeacher ? 'শিক্ষক তথ্য আপডেট' : 'নতুন শিক্ষক যোগ'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="bg-white/10 p-2 rounded-xl hover:bg-white/20 transition-colors"><X /></button>
            </div>
            <div className="p-8 space-y-6">
              <div>
                <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">নাম</label>
                <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">পদবি</label>
                  <input type="text" value={formData.designation} onChange={e => setFormData({...formData, designation: e.target.value})} placeholder="যেমন: উস্তাদ" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">বিষয়</label>
                  <div className="relative">
                    <select 
                      value={formData.subject} 
                      onChange={e => setFormData({...formData, subject: e.target.value})} 
                      className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold appearance-none"
                    >
                      <option value="">নির্বাচন করুন</option>
                      {subjects.map(s => (
                        <option key={s.id} value={s.name}>{s.name}</option>
                      ))}
                      <option value="অন্যান্য">অন্যান্য</option>
                    </select>
                    <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">মোবাইল</label>
                  <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">যোগদানের তারিখ</label>
                  <input type="date" value={formData.joiningDate} onChange={e => setFormData({...formData, joiningDate: e.target.value})} className="w-full px-5 py-4 rounded-2xl bg-gray-50 border-2 border-transparent outline-none focus:bg-white focus:border-emerald-500 font-bold" />
                </div>
              </div>
              <button onClick={handleSave} className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xl hover:bg-emerald-700 shadow-xl transition-all active:scale-95 mt-4">সংরক্ষণ করুন</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeacherList;
