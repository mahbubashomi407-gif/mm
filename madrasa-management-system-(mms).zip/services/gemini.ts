
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function askMMSAssistant(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are a helpful administrative assistant for a Madrasa Management System (MMS) in Bangladesh. 
        You provide answers in Bengali. Your expertise covers: 
        1. Islamic curriculum advice. 
        2. Student management best practices. 
        3. Financial record keeping tips for educational institutes. 
        4. Drafting letters and notices in Bengali.
        Keep responses polite, professional, and culturally appropriate.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "দুঃখিত, আমি এই মুহূর্তে উত্তর দিতে পারছি না। অনুগ্রহ করে আবার চেষ্টা করুন।";
  }
}
